//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BlackBox.rc
//
#define IDD_DIALOG1                     101
#define IDD_BLACKBOX_ERR_DLG            101
#define IDR_ACCELERATOR1                102
#define IDD_ABOUT_BLACKBOX              103
#define IDD_MACHINE_INFO_DLG            104
#define IDD_MACHINESTATE_DLG            105
#define IDD_INIT_DLG                    106
#define IDI_BUG                         107
#define IDC_INTRO                       1002
#define IDC_COPY_TO_CLIPBOARD           1003
#define IDC_SAVE_TO_FILE                1004
#define IDC_STACKTRACE                  1005
#define IDC_EXCEPTION                   1006
#define IDC_REGISTER                    1007
#define IDC_ABOUT                       1009
#define IDC_SEND                        1010
#define IDC_MACHINE_INFO                1011
#define IDC_CPU_LABEL                   1012
#define IDC_OS_LABEL                    1013
#define IDC_MEM_LABEL                   1014
#define IDC_MACHINE_STATE               1015
#define IDC_PROCESS_LIST                1016
#define IDC_PROCESS_MODULE_LIST         1017
#define IDC_PROGRESS_LABEL              1018
#define IDC_INTRO2                      1022
#define IDC_BUG_LBL                     1023
#define IDC_MAILTO                      1024
#define IDC_SUBMIT_NEW_VCF_BUG          1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
